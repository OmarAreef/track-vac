module.exports = [
    {
        reg_num: 10008980771468,
        pass: 2233,
        userType: 'notVaccinated'

    },
    {
        reg_num: 10008980121468,
        pass: 2233,
        userType: '1stDose'
    },
    {
        reg_num: 10005060708090,
        pass: 2233,
        userType: '2ndDose'
    }

]
